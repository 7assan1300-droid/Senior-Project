const CACHE_NAME = "senior-project-site-v3";
const ASSETS = ['./', './index.html', './styles.css', './script.js', './manifest.json', './service-worker.js', './assets/icon-192.png', './assets/icon-512.png', './assets/figures/desirability_surface.png', './assets/figures/htwgs_contour.png', './assets/figures/hydrogen_bfd.png', './assets/figures/hydrogen_flowsheet.png', './assets/figures/hydrotreater_schematic.png', './assets/figures/integrated_aspen_flowsheet.png', './assets/figures/ltwgs_contour.png', './assets/figures/platformer_schematic.png', './assets/figures/rsm_co_surface.png', './assets/figures/temperature_profile.png'];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.map((k) => (k === CACHE_NAME ? null : caches.delete(k))))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const req = event.request;

  // Network-first for navigation, cache fallback for offline
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put("./index.html", copy));
        return res;
      }).catch(() => caches.match("./index.html"))
    );
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req))
  );
});
