(() => {
  const root = document.documentElement;
  const themeToggle = document.getElementById("themeToggle");
  const yearEl = document.getElementById("year");
  const downloadBtn = document.getElementById("downloadBtn");
  const menuToggle = document.getElementById("menuToggle");
  const primaryNav = document.getElementById("primaryNav");

  if (yearEl) yearEl.textContent = String(new Date().getFullYear());

  // Theme preference
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "light" || savedTheme === "dark") {
    if (savedTheme === "light") root.setAttribute("data-theme", "light");
  } else {
    const prefersLight = window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
    if (prefersLight) root.setAttribute("data-theme", "light");
  }

  themeToggle?.addEventListener("click", () => {
    const isLight = root.getAttribute("data-theme") === "light";
    if (isLight) {
      root.removeAttribute("data-theme");
      localStorage.setItem("theme", "dark");
    } else {
      root.setAttribute("data-theme", "light");
      localStorage.setItem("theme", "light");
    }
  });

  // Export PDF via browser print
  downloadBtn?.addEventListener("click", () => window.print());

  // Mobile menu toggle
  menuToggle?.addEventListener("click", () => {
    if (!primaryNav) return;
    const open = primaryNav.classList.toggle("is-open");
    menuToggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });

  // Close menu when a link is clicked (mobile)
  primaryNav?.querySelectorAll("a").forEach((a) => {
    a.addEventListener("click", () => primaryNav.classList.remove("is-open"));
  });

  // PWA service worker
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", async () => {
      try { await navigator.serviceWorker.register("./service-worker.js"); }
      catch (e) { /* silent */ }
    });
  }

  // Lightbox (tap any .img)
  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightboxImg");
  const lightboxCaption = document.getElementById("lightboxCaption");

  function openLightbox(src, alt, caption){
    if (!lightbox || !lightboxImg || !lightboxCaption) return;
    lightboxImg.src = src;
    lightboxImg.alt = alt || "Figure";
    lightboxCaption.textContent = caption || alt || "";
    lightbox.classList.add("is-open");
    lightbox.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
  }

  function closeLightbox(){
    if (!lightbox || !lightboxImg) return;
    lightbox.classList.remove("is-open");
    lightbox.setAttribute("aria-hidden", "true");
    lightboxImg.src = "";
    document.body.style.overflow = "";
  }

  document.querySelectorAll("img.img").forEach((img) => {
    img.addEventListener("click", () => {
      const figure = img.closest("figure");
      const captionEl = figure?.querySelector(".figure__caption");
      const titleEl = figure?.querySelector(".card__title");
      const caption = captionEl?.textContent || titleEl?.textContent || img.alt || "";
      openLightbox(img.getAttribute("src"), img.alt, caption);
    });
  });

  lightbox?.addEventListener("click", (e) => {
    const target = e.target;
    if (target && target.getAttribute && target.getAttribute("data-close") === "true") closeLightbox();
  });

  window.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeLightbox();
  });
})();