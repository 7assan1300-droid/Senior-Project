# Senior Project Website (Mobile-First)

Title:
SIMULATION AND OPTIMIZATION OF COMMON REFINERY REACTORS: HYDROGEN PLANT, NAPHTHA HYDROTREATER AND NAPHTHA PLATFORMER

## Run Locally (Recommended)
Because this site uses a service worker (offline/PWA), run it with a local server:

### Python
```bash
python -m http.server 8000
```
Open:
http://localhost:8000

### VS Code
Install the “Live Server” extension → Right-click `index.html` → “Open with Live Server”.

## Put It Online (Free)
### GitHub Pages (Recommended)
1. Create a new GitHub repository (e.g., `senior-project-site`).
2. Upload all files (including the `assets/` folder) to the repository root.
3. Go to **Settings → Pages**.
4. Set:
   - Source: Deploy from a branch
   - Branch: `main`
   - Folder: `/(root)`
5. Save. Your link will be like:
   `https://YOURNAME.github.io/senior-project-site/`

### Netlify (Drag & Drop)
1. Create a Netlify account.
2. Drag and drop the extracted folder into “Deploy”.
3. Netlify provides a public URL instantly.

## Notes
- The website is static (HTML/CSS/JS) and compatible with iOS, Android, and PCs.
- Tap any figure to zoom; tables scroll on mobile screens.
